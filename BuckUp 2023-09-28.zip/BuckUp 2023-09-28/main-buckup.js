var w = $('.wrapper').width(); var h = $('.wrapper').height(); $('#canvas1-area').attr('width', w); $('#canvas1-area').attr('height', h);


window.onload = function () {
    tabChange("tab1"); toolsDraw();
};
function tabChange(tabNumber) {  //タブが押された場合動く
    document.getElementById("tab1tools").style.display = "none";
    document.getElementById("tab2tools").style.display = "none";
    document.getElementById("tab3tools").style.display = "none";
    document.getElementById(tabNumber + "tools").style.display = "block";
}

var dotDataStraight = new Array(); //点記録配列の初期化
var dotDataBezier = new Array(); var straightLineNum = 0;
function toolsDraw() {  //toolsが押された場合場合動く
    var canvas1 = document.getElementById("canvas1-area");
    var ctx1 = canvas1.getContext('2d');
    // 点の初期位置   
    let x = canvas1.width / 2; let y = canvas1.height / 2;


    // 点のサイズと色   
    const pointSize = 5; const pointColor = '#2c2300';
    function drawPoint(x, y) {
        ctx1.beginPath();
        ctx1.arc(x, y, pointSize, 0, Math.PI * 2);
        ctx1.fillStyle = pointColor; ctx1.fill();
        ctx1.closePath();
    }
    if (document.getElementById("freehand").checked) { //ブラシ（フリーハンド）が選択されたとき
        console.log("ブラシモード開始");
    }
    if (document.getElementById("straightline").checked) { //直線が選択されたとき     
        console.log("直線モード開始"); ++straightLineNum;
    }
    if (document.getElementById("curve").checked) { //曲線が選択されたとき     
        console.log("曲線モード開始");
        // ctx1.beginPath();    
        // ctx1.moveTo(100, 100);    
        // ctx1.bezierCurveTo(150, 100, 150, 300, 300, 300);    
        // ctx1.stroke();  
    }
    // マウスを動作させているとき   
    canvas1.addEventListener('mousemove', (event) => {
        // マウスの位置を取得     
        x = event.clientX - canvas1.getBoundingClientRect().left;
        y = event.clientY - canvas1.getBoundingClientRect().top;
        // Canvasをクリアして新しい点を描画     
        ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
        //マウスの位置に点を表示     
        drawPoint(x, y);
        //dotDataStrraightにデータがあるとき直線の再描画     
        if (dotDataStraight && dotDataStraight[0] && dotDataStraight[0][0] !== undefined) {
            ctx1.beginPath();
            ctx1.moveTo(dotDataStraight[0][0], dotDataStraight[0][1]); // 最初の座標点へ移動       
            for (var i = 1; i < dotDataStraight.length; i++) {
                ctx1.lineTo(dotDataStraight[i][0], dotDataStraight[i][1]);
            }
            ctx1.stroke();
            //dotDataBezierにデータがありモードが直線のとき直線をカーソルまで伸ばして表示 
            if (document.getElementById("straightline").checked) {
                ctx1.beginPath();
                ctx1.moveTo(dotDataStraight[dotDataStraight.length - 1][0], dotDataStraight[dotDataStraight.length - 1][1]); // 最後の座標点へ移動         
                ctx1.lineTo(x, y);
                ctx1.stroke();
            }
        }
        //dotDataBezierにデータがあるとき曲線の再描画     
        if (dotDataBezier && dotDataBezier[0] && dotDataBezier[0][0] !== undefined) {
            ctx1.beginPath();
            ctx1.moveTo(dotDataBezier[0][0], dotDataBezier[0][1]); // 最初の座標点へ移動       
            for (var i = 1; i < dotDataBezier.length; i++) {
                ctx1.lineTo(dotDataBezier[i][0], dotDataBezier[i][1]);
            } ctx1.stroke();
            //dotDataBezierにデータがありモードが曲線のとき曲線をカーソルまで伸ばして表示       
            if (document.getElementById("curve").checked) {
                ctx1.beginPath();
                ctx1.moveTo(dotDataBezier[dotDataBezier.length - 1][0], dotDataBezier[dotDataBezier.length - 1][1]); // 最後の座標点へ移動         
                ctx1.lineTo(x, y);
                ctx1.stroke();
            }
        }
    });
    canvas1.addEventListener('click', (event) => {
        if (document.getElementById("straightline").checked) {
            dotDataStraight.push([x, y]); console.log(dotDataStraight);
        }
        if (document.getElementById("curve").checked) {
            dotDataBezier.push([x, y]);
        }
    });
}






