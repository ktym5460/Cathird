var w = $('.wrapper').width();
var h = $('.wrapper').height();
$('#canvas1-area').attr('width', w);
$('#canvas1-area').attr('height', h);

//ページがロードされたとき動く
window.onload = function () {
    tabChange("tab1");
    toolsDraw();
    buttonCSS();
};

//タブが押された場合動く
function tabChange(tabNumber) {
    document.getElementById("tab1tools").style.display = "none";
    document.getElementById("tab2tools").style.display = "none";
    document.getElementById("tab3tools").style.display = "none";
    document.getElementById(tabNumber + "tools").style.display = "block";
}

//picture_displayが押されたら動く
function picture_display() {
    if (document.getElementById("picture_display").checked) {
        document.getElementById("pictureDraw").style.visibility = "hidden";
    }
    else {
        document.getElementById("pictureDraw").style.visibility = "visible";
    }
}

// 画像選択後に呼ばれるイベント
$("#picture").on("change", function (e) {
    // 2. 画像ファイルの読み込みクラス
    var reader = new FileReader();

    // 3. 準備が終わったら、id=sample1のsrc属性に選択した画像ファイルの情報を設定
    reader.onload = function (e) {
        $("#pictureDraw").attr("src", e.target.result);
    }

    // 4. 読み込んだ画像ファイルをURLに変換
    reader.readAsDataURL(e.target.files[0]);
    console.log("画像出力");
    document.getElementById("picture_display").checked = false;

});


//初期化
var dotDataArray = [];
var dotDataTempSaveArray = [];
var selectedPoint = null; // 選択された点
var selectedPointType = null;



//キャンバスエリアの設定
var canvas1 = document.getElementById("canvas1-area");
var ctx1 = canvas1.getContext('2d');
ctx1.lineWidth = 2;

//ゴミ箱ボタンが押されたら動く
function allClear() {
    var clearConfirmAns = window.confirm('このボタンを実行するとこのエリアに描いたすべてのデータが削除されます。\n本当に削除しますか？');

    if (dotDataArray && clearConfirmAns) {
        dotDataArray.splice(0);
        ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
    }
}

//戻るボタンが押されたら動く
function back() {
    if (dotDataArray[1]) {
        dotDataTempSaveArray.push(dotDataArray.slice());
        dotDataArray.pop();
        ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
        reDraw();
    }
    buttonCSS();
    console.log(dotDataTempSaveArray);
}

//進むボタンが押されたら動く
function next() {
    if (dotDataTempSaveArray[0]) {
        console.log(dotDataTempSaveArray);
        dotDataArray = dotDataTempSaveArray.pop();
        ctx1.clearRect(0, 0, canvas1.width, canvas1.height);

    }
    reDraw();
    buttonCSS();
}



function toolsDraw() {  //toolsが押された場合場合動く

    // 点の初期位置   
    let x = canvas1.width / 2; let y = canvas1.height / 2;

    if (document.getElementById("move").checked) { //移動が選択されたとき
        console.log("移動モード開始");
    }
    if (document.getElementById("straightline").checked) { //直線が選択されたとき     
        console.log("直線モード開始");
    }
    if (document.getElementById("curve").checked) { //曲線が選択されたとき     
        console.log("曲線モード開始");
    }
    if (document.getElementById("picture").checked) { //画像が選択されたとき     
        pictureDraw();
    }
}

// マウスが動いているとき   
canvas1.addEventListener('mousemove', (event) => {
    document.getElementById("canvas1-area").style.cursor = 'default';//カーソルを変更
    // マウスの位置を取得     
    x = event.clientX - canvas1.getBoundingClientRect().left;
    y = event.clientY - canvas1.getBoundingClientRect().top;

    // Canvasをクリアして新しい点を描画     
    ctx1.clearRect(0, 0, canvas1.width, canvas1.height);


    if (document.getElementById("move").checked) {
        document.getElementById("canvas1-area").style.cursor = 'grab';
    }
    else {
        //マウスの位置に点を表示     
        drawPoint(x, y, '#2c2300', 10);
    }



    //dotDataArrayにデータがあるとき再描画     
    if (dotDataArray[0]) {
        //保存されているdotDataArrayより再描画
        reDraw();
        cursorDraw(x, y);

    }

    //selectedPointにデータがあるとき座標を置き換える
    if (selectedPoint) {
        document.getElementById("canvas1-area").style.cursor = 'grabbing';//カーソルを変更
        if (selectedPointType) {
            selectedPoint.cx = x;
            selectedPoint.cy = y;
        }
        else {
            selectedPoint.x = x;
            selectedPoint.y = y;
        }
    }
});

// マウスダウンしたときの処理
canvas1.addEventListener('mousedown', (event) => {
    if (document.getElementById("move").checked) {
        selectedPoint = findNearestPoint(x, y);
    }
});

// マウスアップしてドラッグが終了したときの処理
canvas1.addEventListener('mouseup', () => {
    if (document.getElementById("move").checked) {
        selectedPoint = null;
    }
});

// マウスが左クリックされたとき
canvas1.addEventListener('click', (event) => {

    if (document.getElementById("straightline").checked) {
        dotDataArray.push({ type: "Straight", x: x, y: y });
    }
    if (document.getElementById("curve").checked) {
        if (dotDataArray[0]) {
            var controlx = (x + dotDataArray[dotDataArray.length - 1].x) / 2;
            var controly = (y + dotDataArray[dotDataArray.length - 1].y) / 2;
        }

        dotDataArray.push({ type: "Curve", x: x, y: y, cx: controlx, cy: controly });
    }

    //console.log(dotDataArray);

    //SaveTempDataを消す
    if (dotDataTempSaveArray) {
        dotDataTempSaveArray.splice(0);
    }
    buttonCSS();

});


// マウスが右クリックされたとき
canvas1.addEventListener('contextmenu', (event) => {
    console.log("右クリック！！");
    document.getElementById("move").checked = true;
});


//点描画する関数
function drawPoint(x, y, pointColor, pointSize) {
    ctx1.fillStyle = pointColor;
    ctx1.fillRect(x - pointSize / 2, y - pointSize / 2, pointSize, pointSize);

}

//二次ベジェ曲線を描画する関数
function curve(x0, y0, x1, y1, x_c, y_c) {


    // ctx1.fillText("x:" + x0 + ",\n y:" + y0, x0 + 20, y0 + 20);
    // ctx1.fillText("x:" + x_c + ",\n y:" + y_c, x_c + 20, y_c + 20);


    for (var t = 0; t < 1; t = t + 0.01) {
        var xt = (1 - t) ** 2 * x0 + 2 * (1 - t) * t * x_c + t ** 2 * x1;
        var yt = (1 - t) ** 2 * y0 + 2 * (1 - t) * t * y_c + t ** 2 * y1;

        ctx1.lineTo(xt, yt);
        // console.log("t:" + t, "xt:" + xt, "xy:" + yt);
    }
    ctx1.stroke();
}


// キャンバス上のクリック位置から最も近い点を探す関数
function findNearestPoint(x, y) {
    let minDistance = Infinity;
    let nearestPoint = null;

    for (var i = 0; i < dotDataArray.length; i++) {
        distance = Math.sqrt((x - dotDataArray[i].x) ** 2 + (y - dotDataArray[i].y) ** 2);
        if (distance < minDistance) {
            minDistance = distance;
            nearestPoint = dotDataArray[i];
            selectedPointType = null;
        }
        if (dotDataArray[i].type == "Curve") {
            distance = Math.sqrt((x - dotDataArray[i].cx) ** 2 + (y - dotDataArray[i].cy) ** 2);
            if (distance < minDistance) {
                minDistance = distance;
                nearestPoint = dotDataArray[i];
                selectedPointType = "Control";
            }
        }
    }

    return nearestPoint;
}


//保存されているdotDataArrayより保存されている最後の点の一つ前まで再描画する関数
function reDraw() {
    ctx1.beginPath();
    ctx1.moveTo(dotDataArray[0].x, dotDataArray[0].y); // 最初の座標点へ移動       

    for (var i = 0; i < dotDataArray.length; i++) {
        if (dotDataArray[i].type == 'Straight') { //点が直線であれば
            ctx1.lineTo(dotDataArray[i].x, dotDataArray[i].y);
            ctx1.strokeStyle = '#2c2300';
            ctx1.stroke();
            drawPoint(dotDataArray[i].x, dotDataArray[i].y, '#2c2300', 8);
        }

        if (dotDataArray[i].type == 'Curve') { //点が曲線であれば

            drawPoint(dotDataArray[i].x, dotDataArray[i].y, '#2c2300', 8);
            drawPoint(dotDataArray[i].cx, dotDataArray[i].cy, '#326EFF', 10);//制御点の点

            if (i != 0) {
                moveTo(dotDataArray[i].x, dotDataArray[i].y);
                curve(dotDataArray[i - 1].x, dotDataArray[i - 1].y, dotDataArray[i].x, dotDataArray[i].y, dotDataArray[i].cx, dotDataArray[i].cy);

            }
        }
    }


}

//最後の点からカーソルまでを描画する関数
function cursorDraw(x, y) {
    if (document.getElementById("straightline").checked) {
        ctx1.beginPath();
        ctx1.moveTo(dotDataArray[dotDataArray.length - 1].x, dotDataArray[dotDataArray.length - 1].y); // 最後の座標点へ移動         
        ctx1.lineTo(x, y);
        ctx1.stroke();
    }
    if (document.getElementById("curve").checked) {
        ctx1.beginPath();
        ctx1.moveTo(dotDataArray[dotDataArray.length - 1].x, dotDataArray[dotDataArray.length - 1].y); // 最後の座標点へ移動      
        var controlx = (x + dotDataArray[dotDataArray.length - 1].x) / 2;
        var controly = (y + dotDataArray[dotDataArray.length - 1].y) / 2;
        drawPoint(controlx, controly, '#326EFF', 10);//制御点の描画
        curve(dotDataArray[dotDataArray.length - 1].x, dotDataArray[dotDataArray.length - 1].y, x, y, controlx, controly);
    }
}


//配列のデータの有無によって進むボタンと戻るボタンの表示を変える関数
function buttonCSS() {
    if (dotDataArray[0]) {
        document.getElementById('button_back').disabled = false;
    }
    else {
        document.getElementById('button_back').disabled = true;
    }
    if (dotDataTempSaveArray[0]) {
        document.getElementById('button_next').disabled = false;
    }
    else {
        document.getElementById('button_next').disabled = true;
    }
}

