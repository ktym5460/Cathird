for (var t = 1; t >= 0; t = t - stepT) {
    var xt = ((xc1 - 2 * x + xc2) * t * t) + ((-2 * xc1 + 2 * x) * t) + xc1
    var yt = ((yc1 - 2 * y + yc2) * t * t) + ((-2 * yc1 + 2 * y) * t) + yc1
    context.lineTo(xt, yt);
    console.log("t:"+t, xt, yt);
}