function setCanvasSize() {
    var w = $('.wrapper').width();
    var h = $('.wrapper').height();
    $('#canvas1-area').attr('width', w);
    $('#canvas1-area').attr('height', h);

    var w2 = $('.wrapper').width();
    var h2 = $('.wrapper').height();
    $('#canvas2-area').attr('width', w2);
    $('#canvas2-area').attr('height', h2);
    var w3 = $('.wrapper').width();
    var h3 = $('.wrapper').height();
    $('#canvas3-area').attr('width', w3);
    $('#canvas3-area').attr('height', h3);
    var w4 = $('.wrapper').width();
    var h4 = $('.wrapper').height();
    $('#canvas4-area').attr('width', w4);
    $('#canvas4-area').attr('height', h4);
}


//初期化
var objectDataArray = [];
var objectTempSaveArray = [];
var selectedPoint = null; // 選択された点
var selectedPointType = null;

var holeDataArray = [];
holeDataArray.push({ type: "penUp" });

var holeTempSaveArray = [];


var circuitDataArray = [];
circuitDataArray.push({ type: "penUp" });
var circuitTempSaveArray = [];



modeMove = document.getElementById('move');
modeStraight = document.getElementById('straight');
modeCurve = document.getElementById('curve');
modePicture = document.getElementById('picture');
modeParts = null;

modeMove2 = document.getElementById('move2');
modeHoleStraight = document.getElementById('holeStraight');
modeHoleCurve = document.getElementById('holeCurve');

modeMove3 = document.getElementById('move3');
modeWireStraight = document.getElementById('wireStraight');
modeWireCurve = document.getElementById('wireCurve');

partsAngleDisplayFlug = true;





//キャンバスエリアの設定
var canvas1 = document.getElementById("canvas1-area");
var ctx1 = canvas1.getContext('2d');
var canvas2 = document.getElementById("canvas2-area");
var ctx2 = canvas2.getContext('2d');
var canvas3 = document.getElementById("canvas3-area");
var ctx3 = canvas3.getContext('2d');
var canvas4 = document.getElementById("canvas4-area");
var ctx4 = canvas4.getContext('2d');

ctx1.lineWidth = 2;
ctx4.lineWidth = 2;

cursorColor = "#2c2300";
CursorSize = "4";

controlPointColor = "#326EFF";
controlPointSize = "3";


surfaceColor = "#FFD13180"
holeColor = "#7E630080";
surfaceHoleColor = "#ffffff";
dentColor = "#7E630080";

markPointColor = "red";
markPointSize = "4";

lineColor = "#2c2300";
lineWidth = "2";
holeLineWidth = "1";
straightPointColor = "#2c2300";
straightPointSize = "45";

curvePointColor = "#2c2300";
curvePointSize = "4";

partsPointColor = "#2c2300";
partsPointSize = "4";

holePointColor = "#2c2300";
holePointSize = "1";


var parts = {
    resistance: {
        type: "resistance",
        picSource: "PicSource/Parts/resistance.png",
        width: 70,
        height: 20,
        hole: {
            1: {
                holeLength: 35,
                holeAngle: 0,
                holeR: 10,
                holeType: true,

                snapLength: 80,
                snapAngle: 0,
                snapWidth: 50,
                snapHeight: 20

            },
            2: {
                holeLength: 35,
                holeAngle: 180,
                holeR: 10,
                holeType: true,

                snapLength: 80,
                snapAngle: 180,
                snapWidth: 50,
                snapHeight: 20
            }
        },
        modelSource: `translate([0,0,-t])
        union(){
        linear_extrude(height = t )
            polygon([[-1.5,0.9],[1.5,0.9],[1.5,-0.9],[-1.5,-0.9]]);
        translate([-2,0,0])
        cylinder(h = t, r=1);
        translate([2,0,0])
        cylinder(h = t, r=1);
        }`

    },
    led: {
        type: "led",
        picSource: "PicSource/Parts/led.png",
        width: 40,
        height: 40,
        hole: {
            1: {
                holeLength: 20,
                holeAngle: 0,
                holeR: 10,
                holeType: true,

                snapLength: 80,
                snapAngle: 0,
                snapWidth: 50,
                snapHeight: 20
            },
            2: {
                holeLength: 20,
                holeAngle: 180,
                holeR: 10,
                holeType: true,

                snapLength: 80,
                snapAngle: 180,
                snapWidth: 50,
                snapHeight: 20
            }
        },
        modelSource: `translate([0,0,-t])
        union(){
        cylinder(h = t, r=2);
        }`
    },
    tactSwitch: {
        type: "tactSwitch",
        picSource: "PicSource/Parts/tactSwitch.png",
        width: 60,
        height: 60,
        hole: {
            1: {
                holeLength: 30,
                holeAngle: 0,
                holeR: 10,
                holeType: true,

                snapLength: 60,
                snapAngle: 0,
                snapWidth: 50,
                snapHeight: 20
            },
            2: {
                holeLength: 30,
                holeAngle: 180,
                holeR: 10,
                holeType: true,

                snapLength: 60,
                snapAngle: 180,
                snapWidth: 50,
                snapHeight: 20
            }
        },
        modelSource: `translate([0,0,-t])
        linear_extrude(height = t )
            polygon([[1.5,3],[3,1.5],[3,-1.5],[1.5,-3],[-1.5,-3],[-3,-1.5],[-3,1.5],[-1.5,3]]);`
    },

    batteryBox: {
        type: "batteryBox",
        picSource: "PicSource/Parts/batteryBox.png",
        width: 275,
        height: 220,
        hole: {
            1: {
                holeLength: 110,
                holeAngle: 0,
                holeR: 10,
                holeType: true,

                snapLength: 60,
                snapAngle: 0,
                snapWidth: 50,
                snapHeight: 20
            },
            2: {
                holeLength: 90,
                holeAngle: 180,
                holeR: 10,
                holeType: true,

                snapLength: 60,
                snapAngle: 180,
                snapWidth: 50,
                snapHeight: 20
            }
        },
        modelSource: `translate([-1.5,0,-t-2.1])

        union(){
            union(){
                cylinder(h = t, r=11);
                translate([10,0,0])
                    linear_extrude(height = t+1.9 )
                        polygon([[0,3],[6,3],[6,-3],[0,-3]]);
                
                translate([8,5,t])
                cylinder(h = 2.1, r=1);
                translate([-8,5,t])
                cylinder(h = 2.1, r=1);
                translate([0,-9,t])
                cylinder(h = 2.1, r=1);
                translate([-8,0,0])
                    linear_extrude(height = t+1.9 )
                        polygon([[0,3],[3,3],[3,-3],[0,-3]]);
            };
            
        };`
    },

    joint: {
        type: "joint",
        picSource: "",
        width: 0,
        height: 0,
        hole: {
            1: {
                holeLength: 0,
                holeAngle: 0,
                holeR: 10,
                holeType: false,

                snapLength: 50,
                snapAngle: 0,
                snapWidth: 50,
                snapHeight: 20
            },
            2: {
                holeLength: 0,
                holeAngle: 180,
                holeR: 10,
                holeType: false,

                snapLength: 50,
                snapAngle: 180,
                snapWidth: 50,
                snapHeight: 20
            },
            3: {
                holeLength: 0,
                holeAngle: 90,
                holeR: 10,
                holeType: false,

                snapLength: 50,
                snapAngle: 90,
                snapWidth: 50,
                snapHeight: 20
            }

        },
        modelSource: ""
    }

}




//ページがロードされたとき動く
window.onload = function () {
    setCanvasSize()
    tabChange("tab1");
    toolsDraw();
    buttonCSS(objectDataArray, objectTempSaveArray);
};
window.onresize = function () {
    setCanvasSize();
};


//タブが押された場合動く
function tabChange(tabNumber) {
    document.getElementById("tab1tools").style.display = "none";
    document.getElementById("tab2tools").style.display = "none";
    document.getElementById("tab3tools").style.display = "none";
    document.getElementById(tabNumber + "tools").style.display = "block";

    //detail_menuを非表示にする。
    document.getElementById("detail_display").checked = true;
    detail_display('detail_menu1');


    // すべてのCanvasを非表示にする
    canvas1.style.display = "none";
    canvas2.style.display = "none";
    canvas3.style.display = "none";
    canvas4.style.display = "none";

    //outPutボタンを非表示にする
    document.getElementById("button_outPut").style.display = "none";

    if (tabNumber == "tab1") {
        modeMove.checked = true;

        canvas1.style.display = "block";
        ctx1.globalAlpha = 1; // Canvas1の透明度を設定


    }

    //タブ2が選択されていたらキャンバス1,2を描画しオブジェクトの幅、高さをinputに入れる
    if (tabNumber == "tab2") {
        modeMove2.checked = true;

        canvas1.style.display = "block";
        ctx1.globalAlpha = 0.5; // Canvas1の透明度を設定
        canvas2.style.display = "block";
        ctx2.globalAlpha = 1; // Canvas2の透明度を設定


    }

    if (tabNumber == "tab3") {
        modeMove3.checked = true;


        canvas1.style.display = "block";
        ctx1.globalAlpha = 0.5; // Canvas1の透明度を設定

        canvas2.style.display = "block";
        ctx2.globalAlpha = 0.5; // Canvas2の透明度を設定

        canvas3.style.display = "block";
        ctx3.globalAlpha = 0.5; // Canvas3の透明度を設定

        canvas4.style.display = "block";
        ctx4.globalAlpha = 1; // Canvas4の透明度を設定

        //outPutボタンを非表示にする
        document.getElementById("button_outPut").style.display = "block";
    }


}

//picture_displayが押されたら動く
function picture_display() {
    if (document.getElementById("picture_display").checked) {
        document.getElementById("pictureDraw").style.visibility = "hidden";

    }
    else {
        document.getElementById("pictureDraw").style.visibility = "visible";

    }

}

//detail_displayが押されたら動く
function detail_display(id) {
    if (document.getElementById("detail_display").checked) {
        document.getElementById(id).style.display = "none";

    }
    else {
        document.getElementById(id).style.display = "block";
        reloadSize();
    }

}

// 画像選択後に呼ばれるイベント
$("#picture").on("change", function (e) {
    // 2. 画像ファイルの読み込みクラス
    var reader = new FileReader();

    // 3. 準備が終わったら、id=sample1のsrc属性に選択した画像ファイルの情報を設定
    reader.onload = function (e) {
        $("#pictureDraw").attr("src", e.target.result);
    }

    // 4. 読み込んだ画像ファイルをURLに変換
    reader.readAsDataURL(e.target.files[0]);
    console.log("画像出力");
    document.getElementById("picture_display").checked = false;

});




//ゴミ箱ボタンが押されたら動く
function allClear() {
    if (document.getElementById("tab1").checked) {
        canvas = canvas1;
        ctx = ctx1;
        array = objectDataArray;
    }
    if (document.getElementById("tab2").checked) {
        canvas = canvas2;
        ctx = ctx2;
        array = holeDataArray;
    }
    if (document.getElementById("tab3").checked) {
        canvas = canvas4;
        ctx = ctx4;
        array = circuitDataArray;
    }

    var clearConfirmAns = window.confirm('このボタンを実行するとこのエリアに描いたすべてのデータが削除されます。\n本当に削除しますか？');

    if (array && clearConfirmAns) {
        array.splice(0);
        ctx.clearRect(0, 0, canvas.width, canvas.height);
    }
}

//戻るボタンが押されたら動く
function back() {
    if (document.getElementById("tab1").checked) {
        if (objectDataArray[1]) {
            objectTempSaveArray.push(objectDataArray.slice());
            objectDataArray.pop();
            ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
            reDraw(ctx1, objectDataArray);
        }
        buttonCSS(objectDataArray, objectTempSaveArray);
    }

    if (document.getElementById("tab2").checked) {
        if (holeDataArray[1]) {
            console.log(holeDataArray);
            holeTempSaveArray.push(holeDataArray.slice());
            if (holeDataArray[holeDataArray.length - 1].type === "penUp") {
                holeDataArray.splice(-2);
            }
            else {
                holeDataArray.pop();
            }
            ctx2.clearRect(0, 0, canvas2.width, canvas2.height);
            reDraw(ctx2, holeDataArray);

        }
        buttonCSS(holeDataArray, holeTempSaveArray);
    }

    if (document.getElementById("tab3").checked) {

        if (circuitDataArray[1]) {
            circuitTempSaveArray.push(circuitDataArray.slice());
            if (circuitDataArray[circuitDataArray.length - 1].type == "penUp") {
                circuitDataArray.pop();
            }
            while (circuitDataArray[circuitDataArray.length - 1].type === "snapPoint" ||
                circuitDataArray[circuitDataArray.length - 1].type === "holePoint" ||
                circuitDataArray[circuitDataArray.length - 1].type === "partsAngle") {

                circuitDataArray.pop();
            }
            circuitDataArray.pop();
            console.log(circuitDataArray);
            ctx4.clearRect(0, 0, canvas4.width, canvas4.height);
            reDraw(ctx4, circuitDataArray);
        }
        buttonCSS(circuitDataArray, circuitTempSaveArray);
    }

}

//進むボタンが押されたら動く
function next() {
    if (document.getElementById("tab1").checked) {

        if (objectTempSaveArray[0]) {
            objectDataArray = objectTempSaveArray.pop();
            ctx1.clearRect(0, 0, canvas1.width, canvas1.height);

        }
        reDraw(ctx1, objectDataArray);
        buttonCSS(objectDataArray, objectTempSaveArray);
    }
    if (document.getElementById("tab2").checked) {

        if (holeTempSaveArray[0]) {
            holeDataArray = holeTempSaveArray.pop();
            ctx2.clearRect(0, 0, canvas2.width, canvas2.height);

        }
        reDraw(ctx2, holeDataArray);
        buttonCSS(holeDataArray, holeTempSaveArray);
    }
    if (document.getElementById("tab3").checked) {
        if (circuitTempSaveArray[0]) {
            circuitDataArray = circuitTempSaveArray.pop();
            ctx4.clearRect(0, 0, canvas4.width, canvas4.height);

        }
        reDraw(ctx4, circuitDataArray);
        buttonCSS(circuitDataArray, circuitTempSaveArray);
    }

}




function toolsDraw(partsId) {  //toolsが押された場合場合動く

    // 点の初期位置   
    let x = canvas1.width / 2; let y = canvas1.height / 2;

    if (modeMove.checked) { //移動が選択されたとき
        console.log("移動モード開始");
    }
    if (modeStraight.checked) { //直線が選択されたとき     
        console.log("直線モード開始");
    }
    if (modeCurve.checked) { //曲線が選択されたとき     
        console.log("曲線モード開始");
    }
    if (modePicture.checked) { //画像が選択されたとき     
        console.log("画像モード開始");
    }

    if (modeMove2.checked) { //移動が選択されたとき
        console.log("移動モード2開始");

    }
    if (modeHoleStraight.checked) { //導線直線が選択されたとき     
        console.log("穴直線モード開始");


    }
    if (modeHoleCurve.checked) { //導線曲線選択されたとき     
        console.log("穴曲線モード開始");

    }

    if (modeMove3.checked) { //移動が選択されたとき
        console.log("移動モード3開始");
        modeParts = null;
    }
    if (modeWireStraight.checked) { //導線直線が選択されたとき     
        console.log("導線直線モード開始");
        modeParts = null;

    }
    if (modeWireCurve.checked) { //導線曲線選択されたとき     
        console.log("導線曲線モード開始");
        modeParts = null;
    }

    if (partsId) {
        modeParts = document.getElementById(partsId);
        partsData = parts[partsId];
        console.log(partsData);
    }
}

// Canvas1マウスが動いているとき   
canvas1.addEventListener('mousemove', (event) => {

    canvas1.style.cursor = 'default';//カーソルを変更
    // マウスの位置を取得     
    x = event.clientX - canvas1.getBoundingClientRect().left;
    y = event.clientY - canvas1.getBoundingClientRect().top;

    // Canvasをクリアして新しい点を描画     
    ctx1.clearRect(0, 0, canvas1.width, canvas1.height);

    if (modeMove.checked) {
        canvas1.style.cursor = 'grab';
    }
    else {
        //マウスの位置に点を表示     
        drawPoint(x, y, cursorColor, CursorSize, ctx1);
    }

    //objectDataArrayにデータがあるとき再描画     
    if (objectDataArray[0]) {
        //保存されているobjectDataArrayより再描画
        reDraw(ctx1, objectDataArray);
        cursorDraw(x, y, ctx1, objectDataArray);

    }

    //selectedPointにデータがあるとき座標を置き換える
    if (selectedPoint) {
        canvas1.style.cursor = 'grabbing';//カーソルを変更
        if (selectedPointType) {
            selectedPoint.cx = x;
            selectedPoint.cy = y;
        }
        else {
            selectedPoint.x = x;
            selectedPoint.y = y;
        }
    }

    //カーソルが最初の点に近いとき最初の点の色を変える
    if (objectDataArray[1]) {
        distancePoints(x, y, objectDataArray[0].x, objectDataArray[0].y);
        if (distance < 10) {
            drawPoint(objectDataArray[0].x, objectDataArray[0].y, markPointColor, markPointSize, ctx1);
        }
    }

    //modeモードでカーソルが点に近いとき点の色を変える
    if (objectDataArray[1] && modeMove.checked) {
        for (point of objectDataArray) {
            distancePoints(x, y, point.x, point.y);
            if (distance < 10) {

                drawPoint(point.x, point.y, markPointColor, markPointSize, ctx1);
            }
            if (point.type == "curve") {
                distancePoints(x, y, point.cx, point.cy);
                if (distance < 10) {
                    drawPoint(point.cx, point.cy, markPointColor, markPointSize, ctx1);


                    ctx1.strokeStyle = controlPointColor;
                    ctx1.lineWidth = lineWidth;
                    ctx1.beginPath();
                    curve(pointPrevious.x, pointPrevious.y, point.x, point.y, point.cx, point.cy, ctx1);

                }
            }
            pointPrevious = point;
        }
    }

});

// Canvas2マウスが動いているとき   
canvas2.addEventListener('mousemove', (event) => {

    canvas2.style.cursor = 'default';//カーソルを変更
    // マウスの位置を取得     
    x = event.clientX - canvas2.getBoundingClientRect().left;
    y = event.clientY - canvas2.getBoundingClientRect().top;

    // Canvasをクリアして新しい点を描画     
    ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
    ctx2.clearRect(0, 0, canvas2.width, canvas2.height);

    if (modeMove2.checked) {
        canvas2.style.cursor = 'grab';
    }
    else {
        //マウスの位置に点を表示     
        drawPoint(x, y, cursorColor, CursorSize, ctx2);
    }




    //selectedPointにデータがあるとき座標を置き換える
    if (selectedPoint) {
        canvas2.style.cursor = 'grabbing';//カーソルを変更

        if (selectedPointType == "Control") {
            selectedPoint.cx = x;
            selectedPoint.cy = y;
        }
        else {
            selectedPoint.x = x;
            selectedPoint.y = y;
        }
    }

    //objectDataArrayにデータがあるとき再描画    
    if (objectDataArray[0]) {
        reDraw(ctx1, objectDataArray);
    }
    //holeDataArrayにデータがあるとき再描画     
    if (holeDataArray[0]) {
        //保存されているobjectDataArrayより再描画
        reDraw(ctx2, holeDataArray);
        cursorDraw(x, y, ctx2, holeDataArray);

    }

    //カーソルが最初の点に近いとき最初の点の色を変える
    if (holeDataArray[1]) {
        distancePoints(x, y, holeDataArray[0].x, holeDataArray[0].y);
        if (distance < 10) {
            drawPoint(holeDataArray[0].x, holeDataArray[0].y, markPointColor, markPointSize, ctx2);
        }
    }


    //カーソルが点に近いとき点の色を変える
    if (holeDataArray[1]) {
        for (point of holeDataArray) {
            if (holeDataArray[holeDataArray.length - 1].type == "penUp" || modeMove2) {//ペンupされているとき、またはmoveモードのとき
                distancePoints(x, y, point.x, point.y);

                if (distance < 10) {
                    drawPoint(point.x, point.y, markPointColor, markPointSize, ctx2);
                }

                if (point.type == "holeCurve") {
                    distancePoints(x, y, point.cx, point.cy);

                    if (distance < 10) {
                        drawPoint(point.cx, point.cy, markPointColor, markPointSize, ctx2);

                        ctx2.beginPath();
                        ctx2.strokeStyle = controlPointColor;
                        ctx2.lineWidth = lineWidth;
                        curve(pointPrevious.x, pointPrevious.y, point.x, point.y, point.cx, point.cy, ctx2);

                    }
                }

            }

            else if (point.x != holeDataArray[choleDataArray.length - 1].x && point.y != holeDataArray[holeDataArray.length - 1].y) {
                distancePoints(x, y, point.x, point.y);
                if (distance < 10) {
                    drawPoint(point.x, point.y, markPointColor, markPointSize, ctx2);
                }
            }
            pointPrevious = point;
        }
    }





});

// Canvas4マウスが動いているとき 
canvas4.addEventListener('mousemove', (event) => {
    canvas4.style.cursor = 'default';//カーソルを変更

    // マウスの位置を取得     
    x = event.clientX - canvas4.getBoundingClientRect().left;
    y = event.clientY - canvas4.getBoundingClientRect().top;

    // Canvasをクリアして新しい点を描画     
    ctx1.clearRect(0, 0, canvas1.width, canvas1.height);
    ctx4.clearRect(0, 0, canvas4.width, canvas4.height);

    if (modeMove3.checked) {
        canvas4.style.cursor = 'grab';
    }

    //Partsが選択されているとき
    else if (modeParts && modeParts.checked) {

        drawParts(ctx4, x, y, 0, partsData);

    }
    else {
        //マウスの位置に点を表示     
        drawPoint(x, y, cursorColor, CursorSize, ctx4);

    }

    //objectDataArrayにデータがあるとき再描画    
    if (objectDataArray[0]) {
        reDraw(ctx1, objectDataArray);
    }
    //holeDataArrayにデータがあるとき再描画     
    if (holeDataArray[0]) {
        //保存されているobjectDataArrayより再描画
        reDraw(ctx2, holeDataArray);
    }

    //circuitDataArrayにデータがあるとき再描画     
    if (circuitDataArray[0]) {
        //保存されているobjectDataArrayより再描画
        reDraw(ctx4, circuitDataArray);

        cursorDraw(x, y, ctx4, circuitDataArray);

    }


    //カーソルが点に近いとき点の色を変える
    if (circuitDataArray[1]) {
        for (point of circuitDataArray) {
            if (circuitDataArray[circuitDataArray.length - 1].type == "penUp" || modeMove3) {//ペンupされているとき、またはmoveモードのとき
                distancePoints(x, y, point.x, point.y);

                if (distance < 10 && point.type != "holePoint") {
                    if (point.type == "partsAngle") {
                        if (partsAngleDisplayFlug == true && parts[point.partsType].width != 0 && parts[point.partsType].height != 0) {
                            var img = new Image();
                            img.src = "PicSource/rotateHighlight.png";
                            // 画像を描画

                            ctx4.beginPath();
                            ctx4.save();
                            ctx4.translate(point.x, point.y);
                            ctx4.rotate(Number(pointPrevious.angle) * Math.PI / 180);

                            ctx4.drawImage(img, 0 - 10, 0 - 10, 20, 20);
                            ctx4.restore();
                        }
                    }
                    else {
                        drawPoint(point.x, point.y, markPointColor, markPointSize, ctx4);
                    }

                }

                if (point.type == "wireCurve") {
                    distancePoints(x, y, point.cx, point.cy);

                    if (distance < 10) {
                        drawPoint(point.cx, point.cy, markPointColor, markPointSize, ctx4);

                        ctx4.beginPath();
                        ctx4.strokeStyle = controlPointColor;
                        ctx4.lineWidth = lineWidth;
                        curve(pointPrevious.x, pointPrevious.y, point.x, point.y, point.cx, point.cy, ctx4);

                    }
                }


            }

            else if (point.x != circuitDataArray[circuitDataArray.length - 1].x && point.y != circuitDataArray[circuitDataArray.length - 1].y) {
                distancePoints(x, y, point.x, point.y);
                if (distance < 10) {
                    drawPoint(point.x, point.y, markPointColor, markPointSize, ctx4);
                }
            }
            pointPrevious = point;
        }
    }

    //selectedPointにデータがあるとき座標を置き換える
    if (selectedPoint) {
        canvas4.style.cursor = 'grabbing';//カーソルを変更

        if (selectedPointType == "Control") {
            selectedPoint.cx = x;
            selectedPoint.cy = y;
        }
        else if (selectedPointType == "rotateParts" && selectedPoint.x && selectedPoint.y) {
            partsAngleDisplayFlug = false;

            selectedPoint.angle = calcAngle(selectedPoint.x, selectedPoint.y, x, y) + 90;

            if (parts[selectedPoint.partsType].width != 0 && parts[selectedPoint.partsType].height != 0) {
                var img = new Image();
                img.src = "PicSource/rotateHighlight.png";
                // 画像を描画

                ctx4.beginPath();
                ctx4.save();
                ctx4.translate(x, y);
                ctx4.rotate(Number(selectedPoint.angle) * Math.PI / 180);

                ctx4.drawImage(img, 0 - 10, 0 - 10, 20, 20);
                ctx4.restore();

            }



        }
        else if (selectedPointType == "rotateSnap") {


            selectedPoint.angle = calcAngle(selectedPoint.x, selectedPoint.y, x, y);
        }

        else {
            selectedPoint.x = x;
            selectedPoint.y = y;
        }
    }
    else {
        partsAngleDisplayFlug = true;
    }

});

// マウスダウンしたときの処理
canvas1.addEventListener('mousedown', (event) => {
    if (modeMove.checked) {
        selectedPoint = findNearestPoint(x, y, objectDataArray);
    }

});

canvas2.addEventListener('mousedown', (event) => {
    if (modeMove2.checked) {
        selectedPoint = findNearestPoint(x, y, holeDataArray);
    }

});

canvas4.addEventListener('mousedown', (event) => {
    if (modeMove3.checked) {
        selectedPoint = findNearestPoint(x, y, circuitDataArray);

    }

});



// マウスアップしてドラッグが終了したときの処理
canvas1.addEventListener('mouseup', () => {
    if (modeMove.checked) {
        if (objectDataArray[1]) {
            distancePoints(objectDataArray[objectDataArray.length - 1].x, objectDataArray[objectDataArray.length - 1].y, objectDataArray[0].x, objectDataArray[0].y);
            if (distance < 10) {
                objectDataArray[0].x = objectDataArray[objectDataArray.length - 1].x;
                objectDataArray[0].y = objectDataArray[objectDataArray.length - 1].y;
            }
        }

        selectedPoint = null;

    }
});

canvas2.addEventListener('mouseup', () => {
    if (modeMove2.checked) {
        if (holeDataArray[1]) {
            for (point of holeDataArray) {
                if (point.type != "penUp") {

                    distancePoints(x, y, point.x, point.y);
                    if (distance < 10) {
                        selectedPoint.x = point.x;
                        selectedPoint.y = point.y;
                    }
                }

            }
        }
        selectedPoint = null;

    }
});

canvas4.addEventListener('mouseup', () => {
    //Move3でマウスが上がったとき座標が近い点があれば座標をを置き換える
    if (modeMove3.checked) {
        if (circuitDataArray[1]) {
            for (point of circuitDataArray) {
                if (point.type != "penUp") {

                    distancePoints(x, y, point.x, point.y);
                    if (distance < 10 && selectedPointType != "rotateParts" && selectedPointType != "rotateSnap") {
                        selectedPoint.x = point.x;
                        selectedPoint.y = point.y;
                    }
                }

            }
        }
        selectedPoint = null;

    }
});



// Canvas1マウスが左クリックされたとき
canvas1.addEventListener('click', (event) => {

    if (modeStraight.checked) {
        objectDataArray.push({ type: "straight", x: x, y: y });
    }
    if (modeCurve.checked) {
        if (objectDataArray[0]) {
            var controlx = (x + objectDataArray[objectDataArray.length - 1].x) / 2;
            var controly = (y + objectDataArray[objectDataArray.length - 1].y) / 2;
        }

        objectDataArray.push({ type: "curve", x: x, y: y, cx: controlx, cy: controly });

    }


    //最後の点と最初の点の距離が20以下だと最後の点の座標を最初の点のものに置き換える。
    if (objectDataArray[1] && x != objectDataArray[0].x && y != objectDataArray[0].y) {
        distancePoints(x, y, objectDataArray[0].x, objectDataArray[0].y);
        if (distance < 10) {
            objectDataArray[objectDataArray.length - 1].x = objectDataArray[0].x;
            objectDataArray[objectDataArray.length - 1].y = objectDataArray[0].y;
            modeMove.checked = true;
        }
    }

    //SaveTempDataを消す
    if (objectTempSaveArray) {
        objectTempSaveArray.splice(0);
        buttonCSS(objectDataArray, objectTempSaveArray);
    }



});

// Canvas2マウスが左クリックされたとき
canvas2.addEventListener('click', (event) => {

    if (modeHoleStraight.checked) {
        holeDataArray.push({ type: "holeStraight", x: x, y: y });
    }
    if (modeHoleCurve.checked) {
        if (holeDataArray[0]) {
            var controlx = (x + holeDataArray[holeDataArray.length - 1].x) / 2;
            var controly = (y + holeDataArray[holeDataArray.length - 1].y) / 2;
        }

        holeDataArray.push({ type: "holeCurve", x: x, y: y, cx: controlx, cy: controly });

    }


    //クリック点がholeDataArray内の点と近いとき最後の値をその値に置き換える
    if (holeDataArray[1] && modeMove2.checked != true) {
        for (point of holeDataArray) {
            distancePoints(x, y, point.x, point.y);
            if (distance < 10) {
                holeDataArray[holeDataArray.length - 1].x = point.x;
                holeDataArray[holeDataArray.length - 1].y = point.y;
            }
        }
    }

    //SaveTempDataを消す
    if (holeTempSaveArray) {
        holeTempSaveArray.splice(0);
        buttonCSS(holeDataArray, holeTempSaveArray);
    }



});


// Canvas4マウスが左クリックされたとき
canvas4.addEventListener('click', (event) => {

    if (modeWireStraight.checked) {
        circuitDataArray.push({ type: "wireStraight", x: x, y: y });
    }
    if (modeWireCurve.checked) {
        if (circuitDataArray[0]) {
            var controlx = (x + circuitDataArray[circuitDataArray.length - 1].x) / 2;
            var controly = (y + circuitDataArray[circuitDataArray.length - 1].y) / 2;
        }

        circuitDataArray.push({ type: "wireCurve", x: x, y: y, cx: controlx, cy: controly });

    }
    //パーツのとき
    if (modeParts && modeParts.checked) {
        pushParts(circuitDataArray, x, y, partsData);

    }


    //クリック点がcircuitDataArray内の点と近いとき最後の値をその値に置き換える
    if (circuitDataArray[1] && modeMove3.checked != true) {
        for (point of circuitDataArray) {
            distancePoints(x, y, point.x, point.y);
            if (distance < 10 && point.type != "holePoint") {
                circuitDataArray[circuitDataArray.length - 1].x = point.x;
                circuitDataArray[circuitDataArray.length - 1].y = point.y;
            }
        }
    }




    //SaveTempDataを消す
    if (circuitTempSaveArray) {
        circuitTempSaveArray.splice(0);
        buttonCSS(circuitDataArray, circuitTempSaveArray);
    }

});


// canvas1マウスが右クリックされたとき
canvas1.addEventListener('contextmenu', (event) => {
    console.log("右クリック！！");
    modeMove.checked = true;
});

// canvas2マウスが右クリックされたとき
canvas2.addEventListener('contextmenu', (event) => {
    console.log("右クリック！！");
    modeMove2.checked = true;
});

// canvas4マウスが右クリックされたとき
canvas4.addEventListener('contextmenu', (event) => {
    console.log("右クリック！！");

    if (circuitDataArray[circuitDataArray.length - 1].type != "penUp") {
        circuitDataArray.push({ type: "penUp" });
    }

    modeMove3.checked = true;
});



//点描画する関数
function drawPoint(x, y, pointColor, pointSize, ctx) {
    ctx.beginPath();
    ctx.strokeStyle = pointColor;
    ctx.moveTo(x + Number(pointSize), y);
    ctx.arc(x, y, pointSize, 0, 2 * Math.PI);
    ctx.stroke();
    ctx.fillStyle = pointColor;
    ctx.fill();
    ctx.moveTo(x, y);

}

//二次ベジェ曲線を描画する関数
function curve(x0, y0, x1, y1, x_c, y_c, ctx) {
    ctx.lineWidth = lineWidth;
    ctx.lineColor = lineColor;
    for (var t = 0; t < 1; t = t + 0.01) {
        var xt = (1 - t) ** 2 * x0 + 2 * (1 - t) * t * x_c + t ** 2 * x1;
        var yt = (1 - t) ** 2 * y0 + 2 * (1 - t) * t * y_c + t ** 2 * y1;

        ctx.lineTo(xt, yt);
    }
    ctx.lineTo(x1, y1);
    ctx.stroke();
}


// キャンバス上のクリック位置から最も近い点を探す関数
function findNearestPoint(x, y, array) {
    let minDistance = Infinity;
    let nearestPoint = null;
    let nearestPointI = null;

    for (var i = 0; i < array.length; i++) {
        distancePoints(x, y, array[i].x, array[i].y);

        if (distance < minDistance) {
            minDistance = distance;
            nearestPoint = array[i];
            nearestPointI = i;
            selectedPointType = null;
        }
        if (array[i].type == "curve" || array[i].type == "holeCurve" || array[i].type == "wireCurve") {
            distancePoints(x, y, array[i].cx, array[i].cy);
            if (distance < minDistance) {
                minDistance = distance;
                nearestPoint = array[i];
                nearestPointI = i;
                selectedPointType = "Control";
            }
        }
    }
    if (nearestPoint) {

        if (nearestPoint.type == "partsAngle") {
            selectedPointType = "rotateParts";
            nearestPoint = array[nearestPointI - 1];
        }

        if (nearestPoint.type == "snapPoint") {

            selectedPointType = "rotateSnap";

            nearestPoint = array[nearestPointI - array[nearestPointI].holeNum];
        }
    }


    return nearestPoint;
}

// 与えられた二点間の距離を返す関数
function distancePoints(x1, y1, x2, y2) {
    distance = Math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2);
    return distance;
}




//保存されている配列を描画する関数
function reDraw(ctx, array) {
    if (document.getElementById("detail_display").checked == false) {
        reloadSize();
    }

    ctx.beginPath();
    ctx.moveTo(array[0].x, array[0].y); // 最初の座標点へ移動       

    for (var i = 0; i < array.length; i++) {
        if (array[i].type == 'straight') { //点が直線であれば
            ctx.lineWidth = lineWidth;
            ctx.lineTo(array[i].x, array[i].y);
            ctx.strokeStyle = lineColor;
            ctx.stroke();

        }

        if (array[i].type == 'curve') { //点が曲線であれば
            if (i != 0) {
                ctx.strokeStyle = lineColor;
                ctx.lineWidth = lineWidth;
                curve(array[i - 1].x, array[i - 1].y, array[i].x, array[i].y, array[i].cx, array[i].cy, ctx);
            }
        }

        if (array[i].type == 'holeStraight') { //点がhole直線であれば
            ctx.lineWidth = lineWidth;
            ctx.lineTo(array[i].x, array[i].y);
            ctx.strokeStyle = lineColor;
            ctx.stroke();
        }
        if (array[i].type == 'holeCurve') { //点がhole曲線であれば


            if (i != 0) {
                moveTo(array[i].x, array[i].y);
                ctx.strokeStyle = lineColor;
                ctx.lineWidth = lineWidth;
                curve(array[i - 1].x, array[i - 1].y, array[i].x, array[i].y, array[i].cx, array[i].cy, ctx);
            }
        }

        if (array[i].type == 'penUp') {//点がpenUpであれば
            if (array[i + 1]) {
                ctx.moveTo(array[i + 1].x, array[i + 1].y);
            }

            if (array == holeDataArray) {
                penUpI = i;
                ctx2.fillStyle = surfaceHoleColor;
                ctx2.closePath();
                ctx2.fill();
                ctx2.lineWidth = lineWidth;
                ctx2.color = lineColor;
                ctx2.stroke();
            }
        }


        if (array[i].type == 'wireStraight') { //点がwire直線であれば
            ctx.lineWidth = lineWidth;
            ctx.lineTo(array[i].x, array[i].y);
            ctx.strokeStyle = lineColor;
            ctx.lineColor = lineColor;
            ctx.stroke();
        }
        if (array[i].type == 'wireCurve') { //点がwire曲線であれば

            if (i != 0) {
                moveTo(array[i].x, array[i].y);
                ctx.strokeStyle = lineColor;
                ctx.lineWidth = lineWidth;
                curve(array[i - 1].x, array[i - 1].y, array[i].x, array[i].y, array[i].cx, array[i].cy, ctx);
            }
        }
        if (array[i].type == 'parts') { //点がパーツであれば
            drawParts(ctx, array[i].x, array[i].y, array[i].angle, parts[array[i].partsType]);
            resetHoleSnap(array, i, parts[array[i].partsType]);
        }

        if (array[i].type == 'partsAngle' && partsAngleDisplayFlug == true && parts[array[i].partsType].width != 0 && parts[array[i].partsType].height != 0) { //点がパーツアングルであれば

            var img = new Image();
            img.src = "PicSource/rotate.png";
            // 画像を描画

            ctx.beginPath();
            ctx.save();
            ctx.translate(array[i].x, array[i].y);
            ctx.rotate(Number(array[i - 1].angle) * Math.PI / 180);

            ctx.drawImage(img, 0 - 10, 0 - 10, 20, 20);
            ctx.restore();
        }

        if (array[i].type == 'holePoint' && parts[array[i].partsType].hole[array[i].holeCount].holeType == true) { //点がholePointであれば


            ctx.moveTo(array[i].x, array[i].y);
            // holeを描画
            ctx.beginPath();
            ctx.lineWidth = holeLineWidth;
            ctx.lineColor = lineColor;
            ctx.arc(array[i].x, array[i].y, parts[array[i].partsType].hole[array[i].holeCount].holeR, 0, Math.PI * 2, true);

            ctx.fillStyle = holeColor;

            ctx.fill();
            ctx.stroke();



        }
        if (array[i].type == 'snapPoint') { //点がsnapPointであれば
            drawPoint(array[i].x, array[i].y, holePointColor, holePointSize, ctx);
            const samePoint = array.find(element =>
                element != array[i] &&
                element.x === array[i].x &&
                element.y === array[i].y

            );
            if (samePoint) {
                drawSquare(array[i].x, array[i].y, Number(parts[array[i].partsType].hole[array[i].snapCount].snapWidth), Number(parts[array[i].partsType].hole[array[i].snapCount].snapHeight), array[i - array[i].holeNum].angle, dentColor, ctx);
            }


            ctx.beginPath();
            ctx.lineWidth = lineWidth;
            ctx.lineColor = lineColor;
            ctx.moveTo(array[i - array[i].holeNum].x, array[i - array[i].holeNum].y); // 最後の座標点へ移動         
            ctx.lineTo(array[i].x, array[i].y);
            ctx.stroke();

        }


    }
    //objectDataArrayで最後の点が最初の点と同じ座標のとき線形を閉じ面に色をつける
    if (array == objectDataArray && array[1] && array[array.length - 1].x == array[0].x && array[array.length - 1].y == array[0].y) {

        ctx1.fillStyle = surfaceColor;
        ctx1.fill();
        ctx1.stroke();

    }


    //holeDataArrayで最後の点が最後のpenUpの次の点と同じ座標のときpenUpを挿入する。
    if (array == holeDataArray && array[array.length - 1] && array[penUpI + 1] && array.length - 1 != penUpI + 1 && array[array.length - 1].x == array[penUpI + 1].x && array[array.length - 1].y == array[penUpI + 1].y) {
        ctx2.fillStyle = holeColor;
        ctx2.closePath();
        ctx2.fill();

        array.push({ type: "penUp" });
        modeMove2.checked = true;


    }

    ctx.beginPath();
    for (var i = 0; i < array.length; i++) {
        if (array[i].type != "holePoint" && array[i].type != "partsAngle" && array[i].type != "parts") {
            drawPoint(array[i].x, array[i].y, curvePointColor, curvePointSize, ctx);
        }

        if (array[i].cx && array[i].cy) {
            drawPoint(array[i].cx, array[i].cy, controlPointColor, controlPointSize, ctx);//制御点の点
        }
    }


}

//最後の点からカーソルまでを描画する関数
function cursorDraw(x, y, ctx, array) {
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = lineWidth;
    let controlx = "";
    let controly = "";
    if (modeStraight.checked) {
        ctx.beginPath();
        ctx.moveTo(array[array.length - 1].x, array[array.length - 1].y); // 最後の座標点へ移動     

        ctx.lineTo(x, y);
        ctx.stroke();
    }
    if (modeCurve.checked) {
        ctx.beginPath();
        ctx.moveTo(array[array.length - 1].x, array[array.length - 1].y); // 最後の座標点へ移動      
        controlx = (x + array[array.length - 1].x) / 2;
        controly = (y + array[array.length - 1].y) / 2;
        curve(array[array.length - 1].x, array[array.length - 1].y, x, y, controlx, controly, ctx);

    }
    if (modeHoleStraight.checked && array[array.length - 1].type != "penUp") {
        ctx.beginPath();
        ctx.moveTo(array[array.length - 1].x, array[array.length - 1].y); // 最後の座標点へ移動         
        ctx.lineTo(x, y);
        ctx.stroke();
    }
    if (modeHoleCurve.checked && array[array.length - 1].type != "penUp") {
        ctx.beginPath();
        ctx.moveTo(array[array.length - 1].x, array[array.length - 1].y); // 最後の座標点へ移動      
        controlx = (x + array[array.length - 1].x) / 2;
        controly = (y + array[array.length - 1].y) / 2;
        curve(array[array.length - 1].x, array[array.length - 1].y, x, y, controlx, controly, ctx);

    }

    if (modeWireStraight.checked && array[array.length - 1].type != "penUp") {
        ctx.beginPath();
        ctx.moveTo(array[array.length - 1].x, array[array.length - 1].y); // 最後の座標点へ移動         
        ctx.lineTo(x, y);
        ctx.stroke();
    }
    if (modeWireCurve.checked && array[array.length - 1].type != "penUp") {
        ctx.beginPath();
        ctx.moveTo(array[array.length - 1].x, array[array.length - 1].y); // 最後の座標点へ移動      
        controlx = (x + array[array.length - 1].x) / 2;
        controly = (y + array[array.length - 1].y) / 2;

        curve(array[array.length - 1].x, array[array.length - 1].y, x, y, controlx, controly, ctx);

    }
    if (controlx && controly) {
        drawPoint(controlx, controly, controlPointColor, controlPointSize, ctx);//制御点の描画
    }

}


//配列のデータの有無によって進むボタンと戻るボタンの表示を変える関数
function buttonCSS(array, savearray) {
    if (array[0]) {
        document.getElementById('button_back').disabled = false;
    }
    else {
        document.getElementById('button_back').disabled = true;
    }
    if (savearray[0]) {
        document.getElementById('button_next').disabled = false;
    }
    else {
        document.getElementById('button_next').disabled = true;
    }
}

//点の最大の横幅・縦幅を測定する関数
function sizeMeasure(array) {

    var maxX = maxY = null;
    var minX = minY = Infinity;

    for (point of array) {
        if (point.x !== undefined && point.y !== undefined) {
            if (point.x > maxX) {
                maxX = point.x;
            }
            if (point.cx && point.cx > maxX) {
                maxX = point.cx;
            }
            if (point.y > maxY) {
                maxY = point.y;
            }
            if (point.cy && point.cy > maxX) {
                maxY = point.cy;
            }

            if (point.x < minX) {
                minX = point.x;
            }
            if (point.cx && point.cx < minX) {
                minX = point.cx;
            }

            if (point.y < minY) {
                minY = point.y;
            }
            if (point.cy && point.cy < minY) {
                minY = point.cy;
            }
        }

    }

    var objectWidth = parseFloat((distancePoints(maxX, 0, minX, 0) / 10).toFixed(1));
    var objectHeight = parseFloat((distancePoints(0, maxY, 0, minY) / 10).toFixed(1));

    return [objectWidth, objectHeight];
}

function reloadSize() {
    [objectWidth, objectHeight] = sizeMeasure(objectDataArray);
    document.getElementById("sizeWidth").value = objectWidth;
    document.getElementById("sizeHeight").value = objectHeight;
}

//objectの大きさを変える関数
function changeObjectSize(chengedWidth, changedHeight) {
    [objectWidth, objectHeight] = sizeMeasure(objectDataArray);
    if (chengedWidth != objectWidth) {
        console.log("Width変更");
        changeRate = chengedWidth / objectWidth;
    }
    else if (changedHeight != objectHeight) {
        console.log("Height変更");
        changeRate = changedHeight / objectHeight;
    }
    else {
        changeRate = 1;
    }
    console.log(objectDataArray);
    centerWidth = w / 2;
    centerHeight = h / 2;
    console.log(centerWidth, centerHeight);

    // 配列の各要素のxとyにchangeRateをかけて置き換える
    objectDataArray = objectDataArray.map(item => {
        return {
            ...item, // そのままの要素を保持
            x: ((item.x - centerWidth) * changeRate) + centerWidth,
            y: ((item.y - centerHeight) * changeRate) + centerHeight,
            cx: ((item.cx - centerWidth) * changeRate) + centerWidth,
            cy: ((item.cy - centerHeight) * changeRate) + centerHeight
        };
    });

    document.querySelector('img.picture').style.height = parseFloat(getComputedStyle(document.querySelector('img.picture')).height) * changeRate + 'px';
    reDraw();

}


function rotatePoint(centerX, centerY, length, angle) {
    rotatedX = (length * Math.cos((angle) * (Math.PI / 180))) + centerX;
    rotatedY = (length * Math.sin((angle) * (Math.PI / 180))) + centerY;
    return [rotatedX, rotatedY];
}

//部品を描画する関数
function drawParts(ctx, centerX, centerY, angle, parts) {

    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(angle * Math.PI / 180);

    var img = new Image();
    img.src = parts.picSource;
    // 画像を描画
    ctx.drawImage(img, - parts.width / 2, - parts.height / 2, parts.width, parts.height);

    ctx.stroke();


    ctx.restore();
    drawPoint(centerX, centerY, partsPointColor, partsPointSize, ctx);
}

//二点間の角度を求める
function calcAngle(x1, y1, x2, y2) {
    angle = Math.atan2(y2 - y1, x2 - x1) * 180 / Math.PI;

    return angle;
}

//パーツとそのholePointを配列にpushする関数
function pushParts(array, x, y, parts) {

    array.push({ type: "parts", partsType: parts.type, x: x, y: y, angle: 0 });
    partsPlaceNum = array.length - 1;



    rotatePoint(x, y, 20 + parts.height / 2, array[partsPlaceNum].angle);

    array.push({ type: "partsAngle", partsType: parts.type, x: rotatedX, y: rotatedY });




    for (holeCount in parts.hole) {
        holeN = parts.hole[holeCount];
        rotatePoint(x, y, holeN.holeLength, holeN.holeAngle);
        circuitDataArray.push({ type: "holePoint", partsType: parts.type, x: rotatedX, y: rotatedY, angle: holeN.snapAngle, holeNum: Object.keys(parts.hole).length, holeCount: holeCount });
    }
    for (holeCount in parts.hole) {
        holeN = parts.hole[holeCount];

        rotatePoint(array[array.length - Object.keys(parts.hole).length].x, array[array.length - Object.keys(parts.hole).length].y, holeN.snapLength, array[partsPlaceNum].angle);

        circuitDataArray.push({ type: "snapPoint", partsType: parts.type, x: rotatedX, y: rotatedY, holeNum: Object.keys(parts.hole).length, snapCount: holeCount });

    }


}

//穴の位置を再設定する関数
function resetHoleSnap(array, i, parts) {
    [rotatedX, rotatedY] = [];
    [rotatedX, rotatedY] = rotatePoint(array[i].x, array[i].y, 15 + parts.height / 2, array[i].angle - 90);

    if (array[i + 1] && array[i + 1]) {
        array[i + 1].x = rotatedX;
        array[i + 1].y = rotatedY;
    }
    for (holeCount in parts.hole) {
        holeN = parts.hole[holeCount];

        rotatePoint(array[i].x, array[i].y, holeN.holeLength, array[i].angle + holeN.holeAngle);
        if (array[i + 1 + Number(holeCount) + Object.keys(parts.hole).length] && array[i + 1 + Number(holeCount) + Object.keys(parts.hole).length]) {


            array[i + 1 + Number(holeCount)].x = rotatedX;
            array[i + 1 + Number(holeCount)].y = rotatedY;
        }
    }

    for (holeCount in parts.hole) {
        holeN = parts.hole[holeCount];

        if (array[i + 1 + Number(holeCount)]) {
            angle = array[i + 1 + Number(holeCount)].angle;
        }


        if (array[i + 1 + Number(holeCount)]) {
            rotatePoint(array[i + 1 + Number(holeCount)].x, array[i + 1 + Number(holeCount)].y, holeN.snapLength, angle);
        }
        if (array[i + 1 + Number(holeCount) + Object.keys(parts.hole).length]) {

            array[i + 1 + Number(holeCount) + Object.keys(parts.hole).length].x = rotatedX;
            array[i + 1 + Number(holeCount) + Object.keys(parts.hole).length].y = rotatedY;
        }
    }

}


function convertLengthAngle(centerX, centerY, x, y) {
    distancePoints(centerX, centerY, x, y);
    calcAngle(centerX, centerY, x, y);
    return { distance: distance, angle: angle };
}

function drawSquare(x, y, width, height, angle, color, ctx) {
    // holeを描画
    ctx.beginPath();
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(angle * Math.PI / 180);



    ctx.rect(0, - height / 2, -width, height);
    ctx.fillStyle = color;
    ctx.fill();
    ctx.stroke();
    ctx.restore();
}