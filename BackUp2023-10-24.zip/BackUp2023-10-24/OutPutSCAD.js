var Points = [];
var outPutCode;

function makeDots(dataArray) {
    Points = [];
    for (i = 0; i < dataArray.length; i++) {
        if (dataArray[i].type == "straight") {
            Points.push({ x: Math.floor(dataArray[i].x / 10 * Math.pow(10, 1)) / Math.pow(10, 1), y: Math.floor(dataArray[i].y / 10 * Math.pow(10, 1)) / Math.pow(10, 1) });
        }
        if (i != 0 && dataArray[i].type == "curve") {
            for (var t = 0; t < 1; t = t + 0.01) {
                var xt = (1 - t) ** 2 * dataArray[i - 1].x + 2 * (1 - t) * t * dataArray[i].cx + t ** 2 * dataArray[i].x;
                var yt = (1 - t) ** 2 * dataArray[i - 1].y + 2 * (1 - t) * t * dataArray[i].cy + t ** 2 * dataArray[i].y;
                Points.push({ x: Math.floor(xt / 10 * Math.pow(10, 1)) / Math.pow(10, 1), y: Math.floor(yt / 10 * Math.pow(10, 1)) / Math.pow(10, 1) });
            }
        }
    }
    return Points;


}


function makeSolid(points, outHeight, outX, outY, outZ) {
    outPutCode = "translate([" + outX + "," + outY + "," + outZ + "]){linear_extrude(height =" + outHeight + "){polygon(["

    for (i = 0; i < points.length - 1; i++) {
        outPutCode = outPutCode + "[" + points[i].x + "," + points[i].y + "],"
    }
    outPutCode = outPutCode + "[" + points[points.length - 1].x + "," + points[points.length - 1].y + "]]);}}";

    translateSCD(outPutCode);

}

function translateSCD(code){
    // コードをBlob化
    const blob = new Blob([code], { type: 'text/plain' });

    // ダウンロード用のaタグ生成
    const a = document.createElement('a');
    a.href =  URL.createObjectURL(blob);
    a.download = 'sample.scad';
    a.click();
}